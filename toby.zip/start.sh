while :
do
nice -n -19 dotnet TaleWorlds.Starter.DotNetCore.Linux.dll _MODULES_*Native*Multiplayer*swordmusketmptest*_MODULES_ /dedicatedcustomserverconfigfile public.txt /tickrate 90 /dedicatedcustomserverauthtoken TOKENPLS /dedicatedcustomserver 7210 USER 0 /playerhosteddedicatedserver
sleep 1
done
